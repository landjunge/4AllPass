# 4AllPass – Designpaket 2026-10-18.1

Enthält das vorhandene Hell-/Dunkel-Paar der neuen Raster-Icon-Familie. Markenfarbfamilie: **türkis**, wie in den Originalen sichtbar. Keine neue Motivauswahl, Vektorisierung oder Farbänderung.

- `originals/`: unveränderte Bibliotheksbilder
- `png/`: je Variante 13 geprüfte Abmessungen, 16–1024 px
- `windows/`: ICO-Dateien mit mehreren Größen
- `shared/`: festgehaltene gemeinsame Bedienbasis und UI-Farbwerte
- `docs/`: Gestaltungsregeln, Quellen und Einbauprüfung
- `manifest.json`: Quellen, Abmessungen und SHA-256
- `Vorschau.html`: lokale Vorschau beider Varianten und kleiner Größen

**Status:** Paket erstellt, Größen technisch geprüft. Noch keine allgemeine Produkt-/Browser-/Installer-Abnahme. Dieses Paket ändert kein Repository und ersetzt keine historische Version. Bei abweichender aktueller Gestaltungsentscheidung zuerst den Quellenstand klären.

Die Produktidentität bleibt eigenständig. Keine pauschale neue Nutzungslizenz für Quellcode oder Fremdmaterial.
