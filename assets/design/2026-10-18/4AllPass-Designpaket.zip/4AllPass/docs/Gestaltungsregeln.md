# Gemeinsame Gestaltungsregeln

Stand: 18.10.2026. Paketiert vorhandene Vorlagen; keine neue Produktoberfläche und keine automatische Umstellung der Repositories.

## Quelle und Gültigkeit

Die gemeinsame Bedienbasis 0.1 und GOLDENRULES §19 stammen aus dem festgehaltenen ThreadDesk-Commit b0b6815d1996b7d28f374841c616dcb458304848 vom bestehenden Designauftrag. Die damaligen Umsetzungs-/Prüfstände sind historische Angaben, keine neue Prüfung. Neuere ausdrückliche Nutzerentscheidungen haben Vorrang. Kein automatisches Nachladen anderer Repositories.

## Gemeinsame Oberfläche

Systemschrift; Größenrollen 12/14/16/24 px; Bedienelemente 40 px; Abstandsskala 4/8/12/16/24/32 px; eckige Komponenten. Eine klare Hauptaktion, ruhigere Nebenaktionen; Status immer auch als Text. Markenfarbe an Markenpositionen, keine zusätzliche Statussprache.

Die festgehaltene Desktop-Komposition bleibt bei kleinen Fenstern scrollbar statt automatisch gestapelt: vorgesehene Arbeitsfläche 1180×760, Referenz 1440×900 CSS-Pixel. Tastatur, Fokus und Vergrößerung dürfen keine Aktion unzugänglich machen. Keine pauschale Barrierefreiheitsbehauptung.

DE/EN gleichwertig; Produktnamen nicht übersetzen. Keine neue Webfont- oder CDN-Abhängigkeit. Die gemeinsame CSS-Datei liegt unverändert im Paket. Eine helle Icon-Variante bedeutet nicht, dass bereits ein vollständiges helles UI-Farbsystem beschlossen ist.

## Icons

Originale erhalten; heller und dunkler Entwurf bleiben als unterschiedliche Originale erkennbar. Nur proportional skalieren, keine Motive neu zeichnen, kein stiller Zuschnitt und keine erfundene Transparenz. Die vorliegenden PNG-Originale besitzen ihre jeweiligen Hintergründe. Produktfarben sind in den Bildern teils Verläufe; aus Rasterbildern wird kein angeblich verbindlicher Marken-Hexwert erfunden.

13 PNG-Größen je Variante: 16/24/32/48/64/96/128/180/192/256/384/512/1024 px. ICO enthält 16/24/32/48/64/128/256 px. ICNS bei Einbindung mit dem jeweiligen nativen Buildwerkzeug erzeugen und prüfen. Kleine Größen sind technische Ableitungen, keine geprüften optischen Redesigns; Lesbarkeit vor Freigabe im tatsächlichen Einsatz ansehen.

## Wiederholbarer Ablauf für weitere Tools

1. Aktuelle Originale in der Bibliothek ermitteln und visuell prüfen.
2. Quelle, Variante, Datum, Status und Original-Hash festhalten.
3. Größen ableiten und Abmessungen prüfen; Manifest erzeugen.
4. Gemeinsame UI-Basis unverändert plus produktspezifische Markenvorgaben beilegen.
5. README, Einbaucheckliste und Vorschau beilegen.
6. Paket versioniert speichern; Einbindung gesondert durchführen und nachweisen.

## Einbauprüfung

- [ ] App, Installer, Favicon, Erweiterung und Dokumentation verwenden die passende neue Familie.
- [ ] Normale/HiDPI- und kleine Größen im realen Ziel geprüft.
- [ ] Hell/Dunkel-Wahl dokumentiert; keine nicht unterstützte native Automatik behauptet.
- [ ] UI-Zustände, DE/EN, Tastatur und Hauptablauf im Browser geprüft.
- [ ] Historische Releases bleiben unverändert; keine Kryptografie-, Daten- oder Rechteänderung durch ein Designpaket.
